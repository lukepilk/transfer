//
//  ContentView.swift
//  WebWrap
//
//  Created by Luke Pilkington on 12/6/22.
//

import SwiftUI

struct ContentView: View {
    

    private var google: URL = URL(string: "http://google.com")!
    private var RecruitMe: URL = URL(string: "https://recruitme.swf.army.mil")!
    
    
    var body: some View {
       
            WebView(url: RecruitMe)
                    .background(Color(.black).edgesIgnoringSafeArea(.bottom))
                    .background(Color(.black).edgesIgnoringSafeArea(.top))
        
    }

}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
