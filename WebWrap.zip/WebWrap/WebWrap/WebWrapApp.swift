//
//  WebWrapApp.swift
//  WebWrap
//
//  Created by Luke Pilkington on 12/6/22.
//

import SwiftUI

@main
struct WebWrapApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
